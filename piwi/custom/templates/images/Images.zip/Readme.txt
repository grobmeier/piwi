The files contained in this ZIP-File are the images uded for the Piwi-Demo site.
They can be edited with Microsoft Expression Design: http://www.microsoft.com/expression/